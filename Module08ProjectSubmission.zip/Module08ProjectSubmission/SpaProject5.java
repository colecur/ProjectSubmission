// Cole Curcio
// Project Benchmark for Module 05

public class SpaProject5 
{
    private String serviceDescription;
    private double price;

    public SpaProject5() 
    {
        this("XXX", 0);
    }

    public SpaProject5(String desc, double pr)
    {
        serviceDescription = desc;
        price = pr;
    }

    public void setServiceDescription(String product)
    {
        serviceDescription = product;
    }

    public void setPrice(double productPrice)
    {
        price = productPrice;
    }

    public String getServiceDescription()
    {
        return serviceDescription;
    }

    public double getPrice()
    {
        return price;
    }
}