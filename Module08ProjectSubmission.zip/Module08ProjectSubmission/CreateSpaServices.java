// Cole Curcio
// Project Benchmark for Module 04

import java.util.Scanner;
public class CreateSpaServices
{
    public static void main(String[] args) {
        SpaProject firstService = new SpaProject();
        SpaProject secondService = new SpaProject();
        SpaProject thirdService = new SpaProject("FACIAL", 22.99);

        firstService = getData(firstService);
        System.out.println("First service details: ");
        System.out.println(firstService.getServiceDescription() + 
        " $" + firstService.getPrice());

        System.out.println("Second service details: ");
        System.out.println(secondService.getServiceDescription() + 
        " $" + secondService.getPrice());

        System.out.println("Third service details: ");
        System.out.println(thirdService.getServiceDescription() + 
        " $" + thirdService.getPrice());


    }

    public static SpaProject getData(SpaProject service) {
        String serviceDescription;
        double price;
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter service >>");
        serviceDescription = keyboard.nextLine();
        System.out.print("Enter price >>");
        price = keyboard.nextDouble();

        keyboard.nextLine();
        service.setServiceDescription(serviceDescription);
        service.setPrice(price);
        

        return service;

    }
}


