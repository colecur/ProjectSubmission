// Cole Curcio
// Project Benchmark for Module 05 (Update for submission)
public class SpaProject7
{
    private String serviceProduct;
    private int price;
    public SpaProject7() 
    {
        this.serviceProduct = serviceProduct;
    }

    public SpaProject7(String desc, double pr)
    {
        serviceProduct = desc;
        price = (int) pr;
    }

    public void setServiceProduct(String product)
    {
        serviceProduct = product;
    }

    public void setPrice(double productPrice)
    {
        price = (int) productPrice;
    }

    public String getServiceProduct()
    {
        return serviceProduct;
    }

    public double getPrice()
    {
        return price;
    }
}