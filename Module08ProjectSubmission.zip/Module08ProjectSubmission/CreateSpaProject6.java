// Cole Curcio
// Project Benchmark for Module 06 (Update for submission)
import javax.swing.JOptionPane;
public class CreateSpaProject6
{
    public static void main(String[] args) {
        String SpaService;
        String serviceProduct;
        double price;
        SpaService = JOptionPane.showInputDialog(null, "Enter your first service name or enter 0 to quit: ");
        SpaProject6 firstService = new SpaProject6();
        SpaService = JOptionPane.showInputDialog(null, "Enter your second service name: ");
        SpaProject6 secondService = new SpaProject6();
        SpaService = JOptionPane.showInputDialog(null, "Enter your third service name: ");
        SpaProject6 thirdService = new SpaProject6();
        SpaService = JOptionPane.showInputDialog(null, "Enter your fourth service name: ");
        SpaProject6 fourthService = new SpaProject6();
        
    
        JOptionPane.showMessageDialog(null, "First service: " + firstService.getServiceProduct() + 
        "\nPrice: $" + firstService.getPrice());
        JOptionPane.showMessageDialog(null, "Second service: " + secondService.getServiceProduct() + 
        "\nPrice: $" + secondService.getPrice());
        JOptionPane.showMessageDialog(null, "Third service: " + thirdService.getServiceProduct() + 
        "\nPrice: $" + thirdService.getPrice());
        JOptionPane.showMessageDialog(null, "Fourth service: " + fourthService.getServiceProduct() + 
        "\nPrice: $" + fourthService.getPrice());

    }
}


