// Cole Curcio
// Project Benchmark for Module 05 (Update for submission)

import java.util.Scanner;
public class CreateSpaServices5
{

    private static int SpaProject;
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your price for your product in the Spa >> ");
        SpaProject = input.nextInt();
        int PRICE = 0;
        while(SpaProject == PRICE)
        {
            System.out.println("The price of the product is too high for the cost");
            SpaProject = input.nextInt();
        }
        System.out.println("The price of the product is a good pricing for the cost is " + SpaProject + " dollars");
    }
}


