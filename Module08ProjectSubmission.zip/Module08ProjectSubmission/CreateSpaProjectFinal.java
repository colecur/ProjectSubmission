// Cole Curcio
// Project Benchmark for Module 08 (Final)
import java.util.Scanner;
import javax.swing.JFrame;
public class CreateSpaProjectFinal
{
    public static void main(String[] args) 
    {
        String SpaService;
        String serviceProduct;
        int product;
        System.out.print("Enter your product name of this spa >> ");
        Scanner keyboard = new Scanner(System.in);
        System.out.println();
        
    }
    public static void SpaService(String s)
    {
        System.out.print(s);
        int SpaProject = 0;

        SpaService(s.substring(0, SpaProject));
        SpaService(s.substring(SpaProject + 1));
    }
    public class JSpaProject extends JFrame
    {
        final int WIDTH = 500;
        final int HEIGHT = 100;
        public JSpaProject()
        {
            super("Enjoy your spa product");
            setSize(WIDTH, HEIGHT);
        }
    }
}

