// Cole Curcio
// Project Benchmark for Module 05
public class SpaProjectFinal
{
    private String serviceProduct;
    private double price;
    public SpaProjectFinal() 
    {
        this.serviceProduct = serviceProduct;
    }

    public SpaProjectFinal(String desc, double pr)
    {
        serviceProduct = desc;
        price = pr;
    }

    public void setServiceProduct(String product)
    {
        serviceProduct = product;
    }

    public void setPrice(double productPrice)
    {
        price = productPrice;
    }

    public String getServiceProduct()
    {
        return serviceProduct;
    }

    public double getPrice()
    {
        return price;
    }
}