// Cole Curcio
// Project Benchmark for Module 06 (Update for submission)
import java.io.OutputStreamWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
public class CreateSpaProject7
{

    private static Object path;
    public static void main(String[] args) 
    {
        Path fileName = 
         Paths.get(".\\SpaProductNames.txt");
        String name = "Skincare, Luxury, Steamers, Tanning Spray";
        System.out.println("The list of spa products: " + path.toString());
        OutputStreamWriter output = null;
        
    }
}
