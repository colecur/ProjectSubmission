// Cole Curcio
// Project Bookmark for Module 04

public class SpaProject 
{
    private String serviceDescription;
    private double price;

    public SpaProject() 
    {
        this("XXX", 0);
    }

    public SpaProject(String desc, double pr)
    {
        serviceDescription = desc;
        price = pr;
    }

    public void setServiceDescription(String product)
    {
        serviceDescription = product;
    }

    public void setPrice(double productPrice)
    {
        price = productPrice;
    }

    public String getServiceDescription()
    {
        return serviceDescription;
    }

    public double getPrice()
    {
        return price;
    }
}