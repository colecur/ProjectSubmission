// Cole Curcio
// Project Benchmark for Module 05
public class SpaProject6 
{
    private String serviceProduct;
    private double price;
    public SpaProject6() 
    {
        this.serviceProduct = serviceProduct;
    }

    public SpaProject6(String desc, double pr)
    {
        serviceProduct = desc;
        price = pr;
    }

    public void setServiceProduct(String product)
    {
        serviceProduct = product;
    }

    public void setPrice(double productPrice)
    {
        price = productPrice;
    }

    public String getServiceProduct()
    {
        return serviceProduct;
    }

    public double getPrice()
    {
        return price;
    }
}